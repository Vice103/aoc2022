#include <iostream>
#include <fstream>
using namespace std;

int main()
{
  string myText;
  int calories;
  int maximum = 0;
  int temp = 0;

//reading of file
  ifstream caloriesfile("puzzle txt.txt");
//getline() for page breaks
  while (getline(caloriesfile, myText))
  {
    if (myText != "")
    {
      calories = stoi(myText);
      temp += calories;
    }
    else
    {
      if (temp > maximum)
      {
        maximum = temp;
      }
      temp = 0;
    }
  }
  cout << maximum << endl;
}
